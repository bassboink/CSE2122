/* File: thing.cpp
   This file was created by: Mitchell Wendt
   Created on: 7/16/16
   Synopsis: This file contains the member functions of the thing class
*/

#include<map>
#include<set>
#include "thing.h"

Thing::Thing(Room* _current_room)
{
    current_room = _current_room;
}
